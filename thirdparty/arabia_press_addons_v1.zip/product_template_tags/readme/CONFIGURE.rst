To configure this module, you need to:

#. Go to the product form view.
#. Create and edit tags using the form view
