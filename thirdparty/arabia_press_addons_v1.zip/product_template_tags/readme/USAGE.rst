To use this module, you need to:

#. On the product view, you can add and create tags.
#. Tags will be shown in the kanban view.
