""" initialize whole module python packages """
