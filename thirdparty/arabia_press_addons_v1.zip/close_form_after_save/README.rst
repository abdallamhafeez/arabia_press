
.. class:: text-center

Close Form After Save
=====================

.. class:: text-left

Features
--------

- Close form after save when action target is new
- Use `{'save_close': True}` context in the action to close the popup on save
.. class:: text-left

Credits
-------

.. |copy| unicode:: U+000A9 .. COPYRIGHT SIGN
.. |tm| unicode:: U+2122 .. TRADEMARK SIGN

- `Muhamed Abd El-Rhman <muhamed.inbox@gmail.com>`_ |copy|
  `The Accounter <http://www.theaccounter.com>`_ |tm| 2020
