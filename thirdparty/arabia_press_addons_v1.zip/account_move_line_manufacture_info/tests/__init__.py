# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import test_account_move_line_manufacture_info
