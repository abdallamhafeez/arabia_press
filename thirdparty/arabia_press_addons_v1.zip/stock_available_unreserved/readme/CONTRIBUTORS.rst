* Jordi Ballester Alomar <jordi.ballester@forgeflow.com>
* Stefan Rijnhart <stefan@opener.amsterdam>
* Mykhailo Panarin <m.panarin@mobilunity.com>
* Atte Isopuro <atte.isopuro@avoin.systems>
* Lois Rilo <lois.rilo@forgeflow.com>
