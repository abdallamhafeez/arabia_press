# -*- coding: utf-8 -*-
from . import mrp_production_request
