Features:
 - Replace components form production order
